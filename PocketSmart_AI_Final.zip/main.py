from fastapi import FastAPI
from fastapi import Form
from fastapi import UploadFile, File
from pydantic import BaseModel
import os
import json
from dotenv import load_dotenv
from jose import jwt
SECRET_KEY = "pocketsmart-secret-key"
ALGORITHM = "HS256"
from fastapi.responses import HTMLResponse
app = FastAPI()
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
from google import genai
client = genai.Client(api_key=GEMINI_API_KEY)
class HomeRequest(BaseModel):
    budget: int
    room: str


@app.post("/generate-home")
def generate_home(data: HomeRequest):
    prompt = f"""
    Recommend useful home interior products for a {data.room}.
    The total budget is ₹{data.budget}.
    Give 3 suitable products with approximate prices.
    Keep the total within the budget.
    Give a simple explanation for each product.
    """

    try:
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt
        )

        recommendation = response.text

    except Exception:
        recommendation = f"""
        Home Interior Recommendations

        1. LED Lights - ₹800
        Suitable for improving the lighting of your {data.room}.

        2. Decorative Curtains - ₹1,200
        Adds a simple and attractive look to the room.

        3. Wall Decor - ₹700
        Makes the room more attractive.

        These are budget-friendly suggestions for a total budget of ₹{data.budget}.
        """

    history.append({
        "type": "Home Interior",
        "input": {"budget": data.budget, "room": data.room},
        "recommendation": recommendation
    })

    save_history()

    return {"recommendation": recommendation}

class PartyRequest(BaseModel):
    budget: int
    guests: int
    event: str

@app.post("/generate-party")
def generate_party(data: PartyRequest):
    prompt = f"""
    Plan a party with the following details:

    Event type: {data.event}
    Budget: ₹{data.budget}
    Number of guests: {data.guests}

    Create a practical party budget plan.
    Divide the budget among:
    - Catering
    - Decoration
    - Entertainment
    - Venue

    Keep the total within the given budget.
    Give approximate amounts and simple explanations.
    """

    response = client.models.generate_content(
        model="gemini-3.8-flash",
        contents=prompt
    )
    
    history.append({
        "type": "Party Planner",
        "input": {
            "budget": data.budget,
            "guests": data.guests,
            "event": data.event
        },
        "recommendation": response.text
    })
    save_history()

    return {"recommendation": response.text}
    
class JewelryRequest(BaseModel):
    budget: int
    occasion: str
    style: str


@app.post("/generate-jewelry")
def generate_jewelry(data: JewelryRequest):
    prompt = f"""
    Recommend suitable jewelry for the following requirements:

    Budget: ₹{data.budget}
    Occasion: {data.occasion}
    Style: {data.style}

    Suggest 3 suitable jewelry items.
    Give approximate prices.
    Keep the total within the budget.
    Give a simple explanation for each recommendation.
    """

    try:
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt
        )
        recommendation = response.text

    except Exception:
        recommendation = f"""
Jewelry Recommendations

1. Simple Necklace - ₹1,500
Suitable for the selected occasion and style.

2. Matching Earrings - ₹800
A simple matching accessory.

3. Bracelet - ₹500
Adds an elegant finishing touch.

Total estimated cost: ₹2,800
Budget: ₹{data.budget}
"""

    history.append({
        "type": "Jewelry Planner",
        "input": {
            "budget": data.budget,
            "occasion": data.occasion,
            "style": data.style
        },
        "recommendation": recommendation
    })

    save_history()

    return {"recommendation": recommendation}


@app.post("/upload-jewelry-image")
async def upload_jewelry_image(image: UploadFile = File(...)):
    return {
        "filename": image.filename,
        "message": "Jewelry image uploaded successfully"
    }

if os.path.exists("users.json"):
    with open("users.json", "r", encoding="utf-8") as file:
        users = json.load(file)
else:
    users = {}

if os.path.exists("history.json"):
    with open("history.json", "r", encoding="utf-8") as file:
        history = json.load(file)
else:
    history = []
def save_history():
    with open("history.json", "w", encoding="utf-8") as file:
        json.dump(history, file, ensure_ascii=False, indent=4)

@app.get("/register", response_class=HTMLResponse)
def register_page():
    with open("templates/register.html", "r", encoding="utf-8") as file:
        return file.read()

@app.post("/register")
def register(username: str = Form(...), password: str = Form(...)):
    if username in users:
        return {"message": "Username already exists"}

    users[username] = password

    with open("users.json", "w", encoding="utf-8") as file:
        json.dump(users, file, ensure_ascii=False, indent=4)

    return {"message": "Registration successful"}
@app.get("/login", response_class=HTMLResponse)
def login_page():
    with open("templates/login.html", "r", encoding="utf-8") as file:
        return file.read()

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    if username not in users:
        return {"message": "User not found"}

    if users[username] != password:
        return {"message": "Incorrect password"}

    return {"message": "Login successful"}
@app.get("/", response_class=HTMLResponse)
def home():
    with open("templates/index.html", "r", encoding="utf-8") as file:
        return file.read()
@app.get("/home", response_class=HTMLResponse)
def home_planner():
    with open("templates/home.html", "r", encoding="utf-8") as file:
        return file.read()
@app.get("/party", response_class=HTMLResponse)
def party_planner():
    with open("templates/party.html", "r", encoding="utf-8") as file:
        return file.read()
@app.get("/jewelry", response_class=HTMLResponse)
def jewelry_planner():
    with open("templates/jewelry.html", "r", encoding="utf-8") as file:
        return file.read()
@app.get("/test-gemini")
def test_gemini():
    response = client.models.generate_content(
        model="gemini-3.8-flash",
        contents="Say hello in one short sentence."
    )
    return {"gemini_response": response.text}
@app.get("/history-page", response_class=HTMLResponse)
def history_page():
    with open("templates/history.html", "r", encoding="utf-8") as file:
        return file.read()

@app.get("/testimonials", response_class=HTMLResponse)
def testimonials():
    with open("templates/testimonials.html", "r", encoding="utf-8") as file:
        return file.read()

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    with open("templates/dashboard.html", "r", encoding="utf-8") as file:
        return file.read()

@app.get("/logout")
def logout():
    return {"message": "Logged out successfully"}

@app.get("/history")
def get_history():
    return {"history": history}

@app.get("/recommendations-details")
def recommendations_details():
    return {
        "message": "Recommendation details endpoint is working",
        "available_categories": [
            "Home Interior",
            "Party Planner",
            "Jewelry Planner"
        ]
    }
@app.get("/session-info")
def session_info():
    return {
        "message": "Session information endpoint is working",
        "logged_in": True
    }


@app.get("/session-data")
def session_data():
    return {
        "message": "Session data endpoint is working",
        "user": "PocketSmart User"
    }
@app.post("/token")
def create_token(username: str = Form(...), password: str = Form(...)):
    if username not in users:
        return {"message": "User not found"}

    if users[username] != password:
        return {"message": "Incorrect password"}

    token = jwt.encode(
    {"sub": username},
    SECRET_KEY,
    algorithm=ALGORITHM
)

    return {
    "access_token": token,
    "token_type": "bearer"
}